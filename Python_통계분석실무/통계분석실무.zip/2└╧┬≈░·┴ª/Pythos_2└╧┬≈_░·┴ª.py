import os  # 디렉토리 설정
import numpy as np  # 선형대수, 행렬, 벡터
import math  # 각종 수치연산(루트 등)
import pandas as pd  # CSV파일 읽기, DataFrame 객체, 평균, 중앙값, 분산, 표준편차, 사분위수, 상관관계
import matplotlib.pyplot as plt  # 박스플랏, 산점도
import scipy.stats as stats  # 정규분포, t분포, 신뢰구간(z분포, t분포), 가설검정
import statsmodels.api as sm # 비율의 신뢰구간, 비율의 가설검정, two-sample ttest, 평균차의 신뢰구간, 회귀분석
import statsmodels.formula.api as smf
 
# 디렉토리 설정
os.getcwd()
os.chdir('C:/Users/Administrator/Desktop/dataset')
os.getcwd()


# 1번 문제
apt_price = pd.read_csv('apt_price.csv')
apt_price.head(10)

# h0 : mu = 2.95 억 ( 295,000,000 ) = 29500 만원
# h1 : mu > 2.95 억 29500 만원
# price 단위 만원
# n = 200
# 필요값 : 표본 표준 편자 : S
xbar = apt_price['Price'].mean()
sigma = apt_price['Price'].std()
n = len(apt_price)

# 가설검정(one sample t-test)
1-stats.t.cdf(xbar, df=n-1, loc=29500, scale=sigma/math.sqrt(n))


# 2번 문제 - 1번 질문
carsale = pd.read_csv('carsale.csv')
carsale.head(10)

carsale.sales[carsale.location == 'city'].mean()
carsale.sales[carsale.location == 'other'].mean()

# 2번 문제 - 2번 질문
tempdata = pd.get_dummies(carsale['location'], prefix='I')
carsale = carsale.join(tempdata)
carsale.head()

carsale.lm = smf.ols('sales ~ advertise+salesmen+I_city', data=carsale).fit()
carsale.lm.summary()

# 2번 문제 - 3번 질문
temp=[[20,15,0],[20,15,1]]
temp=pd.DataFrame(temp,columns=['advertise','salesmen','I_city'])
carsale.lm.predict(temp)

carsale.lm = smf.ols('sales ~ advertise+salesmen+I_city', data=carsale).fit()
carsale.lm.summary()


