import os  # 디렉토리 설정
import numpy as np  # 선형대수, 행렬, 벡터
import math  # 각종 수치연산(루트 등)
import pandas as pd  # CSV파일 읽기, DataFrame 객체, 평균, 중앙값, 분산, 표준편차, 사분위수, 상관관계
import matplotlib.pyplot as plt  # 박스플랏, 산점도
import scipy.stats as stats  # 정규분포, t분포, 신뢰구간(z분포, t분포), 가설검정
import statsmodels.api as sm # 비율의 신뢰구간, 비율의 가설검정, two-sample ttest, 평균차의 신뢰구간, 회귀분석
import statsmodels.formula.api as smf
 
# 디렉토리 설정
os.getcwd()
os.chdir('C:/Data/')
os.getcwd()

#한 전자회사에서 생산되는 태블릿PC 모집단의 평균무게는 3.2kg 이고 표준편차는 0.4kg 이라고 한다. 
#이 모집단의 분포는 정규분포이다. 임의의 태블릿PC의 무게가 3.1kg과3.3kg 사이에 위치할 확률을 구하시오. (소수점 3자리) 

#CDF를 이용해서 mean = 3.2 이고, sigma = 0.4 인 3.3kg 위치의 확률값 구하기
stats.norm.cdf(x=3.3, loc=3.2, scale = 0.4)

#CDF를 이용해서 mean = 3.2 이고, sigma = 0.4 인 3.1kg 위치의 확률값 구하기
stats.norm.cdf(x=3.1, loc=3.2, scale = 0.4)

# 결과값
stats.norm.cdf(x=3.3, loc=3.2, scale = 0.4) - stats.norm.cdf(x=3.1, loc=3.2, scale = 0.4)


#부동산 시세를 조사하는 모은행에 따르면 지방 A도시내 30평형 아파트의 평균가격은 2.9억원이다. 
#최근 부동산 가격의 상승으로 인하여 평균가격이 더 이상 맞지 않다고 주장하는 사람들이 생겼다. 
#이를 확인해 보기 위해 30평형 200채 아파트의 거래가를 조사하였다. 
#(“apt_price.csv”에 기록, 단위: 만원). 
#A도시내 30평형 아파트의 평균가격에 대한 95% 신뢰구간을 구하고 (소수점 3자리), 
#평균가격이 2.9억원이 아니라고 볼 수 있는지 결론 내리시오. 이 문제의 답은 아래 빈칸을 채우면 됩니다.

# t분포를 사용하여 95%신뢰구간을 구해야 함.

# 데이터 불러오기
data1 = pd.read_csv('apt_price.csv')

# 필요데이터
# 표본 평균(x) = 구하기
# n : 개수 구하기 
# q = 95%이므로 97.5%로 계산 필요

mu = data1['Price'].mean()
n = len(data1['Price'])
nu = n-1
std = data1['Price'].std()

stats.t.interval(0.975, df=nu, loc=mu, scale=std/math.sqrt(n))
