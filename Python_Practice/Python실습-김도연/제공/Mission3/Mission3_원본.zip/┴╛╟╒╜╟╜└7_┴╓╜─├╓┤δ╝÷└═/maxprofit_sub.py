def max_profit(prices):    
    max_profit = 0  # 최대 수익은 항상 0 이상의 값
    purchase_day = 0 # 주식 산 날
    sales_day = 0  # 주식 판 날
    
#------------------------------------------------
# 이 부분에 코딩하시오.









#---------여기까지--------------------------------------   
    
    return purchase_day,sales_day,max_profit

