
def productSales(productList, sales_cnt, survey_grade):
    
    product_dics = {}   #파일에서 읽은 품목별 판매갯수와 평가점수를 담기 위한 dictionary
                        #품목이 key값으로 쓰이고, 판매갯수와 평가점수를 리트스로 만들어 value가 되도록 함
    
    good_products, bad_products = [], []  #우수 상품 리스트와 판매 중지 리스트
    
#------------------------------------------------
# 이 부분에 코딩하시오.









#---------여기까지--------------------------------------   

    good_products = sorted(good_products) #sorted()함수를 이용하여 정렬
    bad_products= sorted(bad_products)    #sorted()함수를 이용하여 정렬
    return good_products, bad_products


