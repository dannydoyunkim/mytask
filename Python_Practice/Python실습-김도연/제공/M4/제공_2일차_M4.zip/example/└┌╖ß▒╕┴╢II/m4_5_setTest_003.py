s1 = set([1,2,3,4,5,6,7])
s2 = set([5,6,7,8,9,10])

print(s1 & s2) 
print(s1.intersection(s2))

print(s1 | s2) 
print(s1.union(s2))

print(s1 - s2)
print(s1.difference(s2))

print(s1 ^ s2) 
