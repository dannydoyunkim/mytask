mySet1 = set([1,3,"python",3.14, 1, "Python"])
mySet2 = set((1,3,5,7,9,3,1,5))
mySet3 = set("Hello Hello LGCNS!")

print(mySet1)  
print(mySet2) 
print(mySet3) 

print("\n데이터 추가 후")
mySet1.add(10)
mySet2.add(100)
mySet3.add('t')

print(mySet1)  
print(mySet2) 
print(mySet3)
