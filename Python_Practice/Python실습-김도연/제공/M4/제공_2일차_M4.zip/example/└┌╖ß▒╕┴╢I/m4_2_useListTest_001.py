ls_int = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
total = 0

for item in ls_int:
    total = total + item

print("1부터 10까지 합은", total, "입니다.")
