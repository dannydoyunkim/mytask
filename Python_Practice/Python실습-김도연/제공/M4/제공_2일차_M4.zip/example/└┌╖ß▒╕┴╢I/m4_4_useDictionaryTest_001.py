myDict1 = {}
myDict2 = dict()

myDict1["park"] = "Seoul"
myDict1["choi"] = "Deagu"

myDict2["park"] = "Busan"
myDict2["choi"] = "Deajeon"

print("park : ", myDict1["park"])
print("choi : ", myDict1["choi"])
print("park : ", myDict2["park"])
print("choi : ", myDict2["choi"])
