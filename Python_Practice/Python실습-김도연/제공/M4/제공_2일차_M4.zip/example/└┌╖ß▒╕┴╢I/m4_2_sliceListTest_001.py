myList = [1,2,3,4,5,6,7,8,9,10]

print("리스트 슬라이싱")
print("1 myList[0 : 3] :", myList[0:3])
print("2 myList[  : 3] :", myList[ :3])
print("3 myList[3 :  ] :", myList[3:])
print("4 myList[-5:-3] :", myList[-5:-3])
print("5 myList[-5:  ] :", myList[-5:])
print("6 myList[  :-3] :", myList[:-3])
