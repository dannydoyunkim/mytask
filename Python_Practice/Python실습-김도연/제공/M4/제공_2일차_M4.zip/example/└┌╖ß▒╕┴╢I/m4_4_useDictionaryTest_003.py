students = {}

students["Name"] = "홍길동"
students["SID"] = "s100"
students["C"] = 90
students["Python"] = 80
students["Java"] = 99

for key in students.keys(): 
    print("{:<6s} : {:<5}".format(key, students[key]))

if "Total" not in students:
    students["Total"] = students["C"]+students["Python"]+students["Java"]

print("{}님의 평균은 {}입니다.".format(students["Name"], students["Total"]))

if "Python" in students:
    students["Python"] += 5

for key in students.keys(): 
    print("{:<6s} : {:<5}".format(key, students[key]))

students.pop("Total")
print("{}님의 평균은 {}입니다.".format(students["Name"], students["Total"]))
