myList1 = [1,2,3,4,5]
myList2 = [6,7,8,9,10]

resList1 = myList1+myList2
resList2 = myList1 * 3

print("1 리스트 더하기 :", resList1)
print("2 리스트 곱하기 :", resList2)

