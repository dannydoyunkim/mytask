import threading
import time

class ThreadExtends(threading.Thread) :
    def run(self) :
        for i in range(5):
            time.sleep(0.1)
            print(threading.currentThread().getName()+'\n', end='')


myThread1 = ThreadExtends(name="First Thread")

myThread1.start();
