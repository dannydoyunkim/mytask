import threading

class ThreadExtends(threading.Thread):
    def run(self) :
        pass



