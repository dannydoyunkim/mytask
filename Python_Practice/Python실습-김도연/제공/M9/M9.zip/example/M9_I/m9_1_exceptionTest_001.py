val1 = int(input("정수1 : "))
val2 = int(input("정수1 : "))


result = val1 / val2

print("{} / {} = {}".format(val1, val2, result))
