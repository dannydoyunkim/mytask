name1 ='Hong Gil Dong'
age1 =30
height1 = 175  #cm 단위
weight1 = 70  #kg 단위

name2 ='Kim Yu Sin'
age2 =20
height2 = 170  #cm 단위
weight2 = 68  #kg 단위

print("이  름 :", name1)
print("나  이 :", age1)
print("몸무게 :", weight1)
print("키(Cm) :", height1)

print("이  름 :", name2)
print("나  이 :", age2)
print("몸무게 :", weight2)
print("키(Cm) :", height2)
