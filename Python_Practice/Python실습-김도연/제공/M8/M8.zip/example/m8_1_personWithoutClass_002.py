person1 = ['Hong Gil Dong', 30, 175, 70]
person2 = ['Kim Yu Sin', 20, 170, 68]


print("이  름 :", person1[0])
print("나  이 :", person1[1])
print("몸무게 :", person1[2])
print("키(Cm) :", person1[3])

print("이  름 :", person2[0])
print("나  이 :", person2[1])
print("몸무게 :", person2[2])
print("키(Cm) :", person2[3])
