    
for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (2, k, 2*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (3, k, 3*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (4, k, 4*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (5, k, 5*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (6, k, 6*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (7, k, 7*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (8, k, 8*k))
print("")

for k in range(1, 10, 1) :
    print(" %d x %d = %2d" % (9, k, 9*k))
print("")  
