sum = 0
for i in range(100) :
    if i % 3 == 0:
        continue
    print(i)
    sum += i

print("조건에 맞는 전체 합 :",sum)    
    
    
