#m3_1_ifelseTest_001.py


baseScore = 60
score = 50

if(score >= baseScore):
    print("통과하였습니다")
else:
    print("통과하지 못하였습니다.")
    

print("프로그램 종료")          

