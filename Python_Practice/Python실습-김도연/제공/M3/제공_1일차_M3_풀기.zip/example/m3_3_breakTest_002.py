for val in range(100): 
    if val % 3 == 0: 
        print(val) 
        break
