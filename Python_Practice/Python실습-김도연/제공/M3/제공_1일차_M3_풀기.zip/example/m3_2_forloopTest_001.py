total = 0

for item in range(0, 101, 2):
    total = total + item

print("1부터 100까지 짝수 합은", total, "입니다.")
