total = 0

for item in "HelloLGCNS":
    total = total + 1

print("문자열은 총", total, "글자로 이뤄져 있습니다.")
