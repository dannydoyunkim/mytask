#m3_1_ifwithoutpassTest_001.py


baseScore = 60
score = 50

if(score >= baseScore):
    #pass

print("프로그램 종료") 

