#m3_1_ifelifelseTest_001.py
#획득한 점수에 따라서 음수 양수, 또는 0으로 메시지 출력

score = 80

if(score > 0):
    print("양수입니다.")
elif( score < 0 ):
    print( "음수 입니다." )
else :
    print( "0 입니다." )
    

print("프로그램 종료")          

