count = 1
total = 0

while count <= 100:
    total = total + count
    count = count + 1

print("1부터 100까지의 합은:", total)
