#m3_1_ifelifelsemultiTest_001.py


score = 80

if(score >= 90):
    print("통과하였습니다")
elif( score >= 80 ):
    print( "B학점 입니다." )
elif ( score >= 70 ):
    print( "C학점 입니다." )
elif(score >= 60 ) :
    print( "D학점 입니다." )
else :
    print( "F학점 입니다." )
    

print("프로그램 종료")          

