a = 0

for i in range(100):
    for j in range(100):
        a = j
        print(a)

        if(a == 15):
            break
print("a = ", a)    
