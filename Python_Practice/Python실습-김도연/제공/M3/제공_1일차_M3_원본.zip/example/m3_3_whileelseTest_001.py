count = 1
result = 0

while count <= 100:
    result = result + count
    count = count + 1
    if count = 100:
        break
else:
     print("덧셈이 작업 완료되었습니다.")

print("1부터 100까지의 합은:", result)
