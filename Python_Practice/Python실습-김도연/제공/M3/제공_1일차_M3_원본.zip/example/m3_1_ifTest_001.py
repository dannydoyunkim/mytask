#m3_1_ifTest_001.py
#획득한 점수가 60점 이상이면 "통과하였습니다" 라는 메시지 출력

baseScore = 60
score = 50

if(score >= baseScore):
    print("통과하였습니다")

print("프로그램 종료")          
