"""
 * [실습] Armstrong Number
 * 
 * Armstrong Number란, 임의의 어떤 수(x)와 그 수의 각 자리 수의 세제곱의 합이 같은 수를 말한다.
 *   예) x = 153 이라면, ( 1 * 1 * 1 ) + ( 5 * 5 * 5 ) + ( 3 * 3 * 3 ) = 153 으로 같으므로, 153은 Armstrong Number 이다.
 * 
 * 100부터 999까지의 숫자 중, Armstrong Number를 구한다.
 * 
 * 
 * [실행 결과]
 * 
 * 153
 * 370
 * 371
 * 407
 * 
 """

      
for inx in range(100, 1000, 1):                 # 100부터 999까지 반복         
     num1 = inx // 100                          # 백의 자리 숫자 분리
     num2 = (inx%100) // 10                     # 십의 자리 숫자 분리
     num3 = ( (inx%100) % 10)                   # 일의 자리 숫자 분리
            
            # 각 자리수 별로 분리한 숫자들의 세제곱의 합을 구한다.     
     result = (num1**3) + (num2**3) + (num3**3)  
            
     if(inx == result ):            
         print( inx )      
       
