"""
 * [실습] IP 주소 알아보기
 * 
 * 32bit의 IP 주소를 입력으로 받아 8자리씩 끊어서 10진수로 바꾸어 출력해 보자.
 * 공백 없이 이진수 32자리 숫자를 입력으로 받아서 우리가 아는 형태의 IP주소인
 * 10진수.10진수.10진수.10진수 로 출력한다.
 * 
 * 
 * [실행 결과]
 * 
 * 11001011100001001110010110000000
 * IP 주소 : 203.132.229.128
 * 
"""

        
binaryIp = "11001011100001001110010110000000"
        
        
# 2진수 형태의 IP 주소를 10진수 형태의 IP 주소로 변환한다.
        
ip1 = binaryIp[0:8]
ip2 = binaryIp[8:16]
ip3 = binaryIp[16:24]
ip4 = binaryIp[24:]

inx1 = int(ip1,2)
inx2 = int(ip2,2)
inx3 = int(ip3,2)
inx4 = int(ip4,2)
        
resultIp = str(inx1) + "." + str(inx2) + "." + str(inx3) + "." + str(inx4)

print( binaryIp )
print( "IP 주소 : " + resultIp )




















