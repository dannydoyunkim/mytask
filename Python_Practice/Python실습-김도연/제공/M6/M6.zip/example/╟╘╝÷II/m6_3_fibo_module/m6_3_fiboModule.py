def fibo(n):                 # 피보나치 수열 결과 리턴
    result = []
    a, b, i = 0, 1, 0
    while i < n:
        result.append(b)
        a, b = b,a + b
        i+=1
    return result
