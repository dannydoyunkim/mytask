from m6_3_moduleTest_001 import sum, safe_sum

print(safe_sum('a', 1))
print(safe_sum(1, 4))
print(sum(10, 10.4))