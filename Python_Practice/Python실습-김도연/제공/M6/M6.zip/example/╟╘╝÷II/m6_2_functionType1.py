def functionType1():
    name, phone = '',''
    name = input("이름 :")
    phone = input("전화 :")

    print("이름 : {}  전화 : {}".format(name, phone))


functionType1()
functionType1() 
    
