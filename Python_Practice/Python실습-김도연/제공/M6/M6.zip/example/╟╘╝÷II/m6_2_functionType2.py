def functionType2(name, phone):
    print("이름 : {}  전화 : {}".format(name, phone))


name, phone = '',''
name = input("이름 :")
phone = input("전화 :")
functionType2(name, phone)

name = input("이름 :")
phone = input("전화 :")
functionType2(name, phone) 
    
