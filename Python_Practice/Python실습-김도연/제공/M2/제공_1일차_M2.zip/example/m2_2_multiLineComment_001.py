"""
다중 문장 주석
code : LGCNS
data : 2018.1.1
"""

num = 10  

print(num)  


'''
실행에서 잠시 제외하고자 할 때도 주석 이용
printf("1")
printf("2")
printf("3")
printf("4")
'''



