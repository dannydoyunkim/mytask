#m2_4_dataType_002.py

val1 = 10
print("1 :", type(val1))  #<class 'int'>
val1 = 3.14
print("1 :", type(val1))  #<class 'float'>
val1 = True
print("1 :", type(val1))  #<class 'bool'>
val1 = "Hello"
print("1 :", type(val1))  #<class 'str'>
