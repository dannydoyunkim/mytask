#m2_bitOp_001.py

a = 0b0000011
b = 0b1100010
 
c =  a & b

print("1 :",a & b)
print("2 :",a | b)
print("3 :",a ^ b)
print("4 :",~a)
print("5 :",a<<2)
print("6 :",a>>2)
