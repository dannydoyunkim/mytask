#m2_logicOp_002.py

a = 100
b = a > 10 and 10 or 20 #a가 10보다 크면 10 아니면 20 
print("1 :",b)

a = 1
b = a > 10 and 10 or 20 #a가 10보다 크면 10 아니면 20 
print("2 :",b)

