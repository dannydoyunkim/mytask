#m2_ComparisonOp_001.py

a = 100
b = 200

print("1 :",a==b)
print("2 :",a!=b)
print("3 :",a>b)
print("4 :",a<b)
print("5 :",a>=b)
print("6 :",a<=b)

