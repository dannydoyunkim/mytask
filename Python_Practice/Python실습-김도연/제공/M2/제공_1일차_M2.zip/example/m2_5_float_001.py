#m2_5_integer_001.py

float_val = 0
float_val = float(input("실수값입력 : "))
print("1 :", type(float_val))
print("2 :", float_val)
print("3 :", float_val+20)
print("4 :", float_val**20)

