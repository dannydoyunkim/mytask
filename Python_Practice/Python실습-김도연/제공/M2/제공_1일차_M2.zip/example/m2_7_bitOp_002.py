#m2_bitOp_002.py

a = 0b0000011
b = 0b1100010
 
print("1 :[a & b 값 :] ", a & b,"[2진코드 :] ",bin(a & b))
print("2 :[a | b 값 :] ", a | b,"[2진코드 :] ",bin(a | b))
print("3 :[a ^ b 값 :] ", a ^ b,"[2진코드 :] ",bin(a ^ b))
print("4 :[   ~a 값 :] ", ~a,"[2진코드 :] ",bin(~a))
print("5 :[a<<2  값 :] ", a<<2,"[2진코드 :] ",bin(a<<2))
print("6 :[a>>2  값 :] ", a>>2,"[2진코드 :] ",bin(a>>2))
