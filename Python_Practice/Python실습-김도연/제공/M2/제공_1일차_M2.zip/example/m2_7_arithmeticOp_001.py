#m2_arithmeticOp_001.py
#상수를 이용한 직접 계산식으로 산술 연산 값 

add = 3 + 25
sub = 45 - 13
mul = 9 * 9
div = 3 / 2       #3을 2로 나눈 값
div_int = 3 // 2  #3을 2로 나눈 몫
mod = 101 % 10    #3을 2로 나눈 나머지
exp = 10 ** 3

print("1 :",add)
print("2 :",sub)
print("3 :",mul)
print("4 :",div)
print("5 :",div_int)
print("6 :",mod)
print("7 :",exp)
