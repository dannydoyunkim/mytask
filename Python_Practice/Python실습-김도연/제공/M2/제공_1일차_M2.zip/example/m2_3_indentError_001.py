#m2_3_indentError_001.py

x = 1
y = 2

if x == 1:
    print(x+10)
   print(y+10)
else:
    print(x+20)
   print(y+20)


