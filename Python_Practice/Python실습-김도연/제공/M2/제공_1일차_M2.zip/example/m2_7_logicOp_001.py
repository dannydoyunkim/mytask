#m2_logicOp_001.py


print(" 1 :",True and True)
print(" 2 :",True and False)
print(" 3 :",False and True)
print(" 4 :",False and False)

print(" 5 :",True or True)
print(" 6 :",True or False)
print(" 7 :",False or True)
print(" 8 :",False or False)

print(" 9 :",not True)
print("10 :",not False)


a = 6
b = 7
c = 42
print("11 :",a == 6)
print("12 :",a == 7)
print("13 :",a == 6 and b == 7)
print("14 :",a == 7 and b == 7)
print("15 :",not a == 7 and b == 7)
print("16 :",a == 7 or b == 7)
print("17 :",a == 7 or b == 6)
print("18 :",not (a == 7 and b == 6))
print("19 :",not a == 7 and b == 6)
