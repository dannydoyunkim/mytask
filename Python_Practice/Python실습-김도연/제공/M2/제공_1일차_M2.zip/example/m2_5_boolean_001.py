#m2_5_boolean_001.py

a = 4
b = 10
test = a > b
print("1 :", type(test))
print("2 :", a > b)
print("3 :", a >= b)
print("4 :", a < b)
print("5 :", a <= b)
print("6 :", a < b)
print("7 :", a <= b  and b == 10)
print("8 :", a >= b  or b == 4)



