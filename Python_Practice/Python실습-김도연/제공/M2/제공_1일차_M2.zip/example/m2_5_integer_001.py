#m2_5_integer_001.py

int_val = 0
int_val = int(input("정수값입력 : "))
print("1 :", type(int_val))
print("2 :", int_val)
print("3 :", int_val+20)
print("4 :", int_val**20)

