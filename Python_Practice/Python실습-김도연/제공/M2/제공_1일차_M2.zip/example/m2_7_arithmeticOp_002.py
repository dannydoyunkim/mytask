#m2_arithmeticOp_002.py
#변수를 이용한 직접 계산식으로 산술 연산 값 

v1 = 20
v2 = 3

add = v1 + v2
sub = v1 - v2
mul = v1 * v2
div = v1 / v2       #v1을 v2로 나눈 값
div_int = v1 // v2  #v1을 v2로 나눈 몫
mod = v1 % v2      #v1을 v2로 나눈 나머지
exp = v1 ** v2

print("1",add)
print("2",sub)
print("3",mul)
print("4",div)
print("5",div_int)
print("6",mod)
print("7",exp)
