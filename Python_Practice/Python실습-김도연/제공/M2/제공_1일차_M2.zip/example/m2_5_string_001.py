#m2_5_string_001.py

a = "1234"
b = 10
tmp = "Hello LGCNS"
c = input("이름 : ")
print("1 :", type(a))
print("2 :", a + '1')
print("3 :", int(a) + 1)
print("4 :", b+5)
print("5 :", str(b)+'5')
print("6 :", "Hello "+c +"!")
print("7 :", "LGCNS"*3)
print("8 :", tmp[6])



