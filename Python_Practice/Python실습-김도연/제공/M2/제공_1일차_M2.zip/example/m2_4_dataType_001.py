#m2_4_dataType_001.py

val1 = 10
print("1 :",val1)

val1 = "Hello"
print("2 :",val1)

val1 = True
print("3 :",val1)

val1 = 123.67
print("3 :",val1)

