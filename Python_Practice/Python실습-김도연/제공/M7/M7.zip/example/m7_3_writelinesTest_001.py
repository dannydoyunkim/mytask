lines = ["LGCNS\n",
         "LGWay\n",
         "Digital Innovation Leader\n"]
 
fp = open('c:/temp/data3.txt', 'w') 
fp.writelines(lines)
fp.close()

