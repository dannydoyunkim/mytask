fp = open('c:/temp/data1.txt', 'r')
allString = fp.read()
fp.close()

print(allString)


