val1 = input("정수값1 : ")
val2 = input("정수값2 : ")

result1 = val1 + val2
print("{} + {} = {}".format(val1, val2, result1))


val1 = int(input("정수값1 : "))
val2 = int(input("정수값2 : "))

result1 = val1 + val2
print("{} + {} = {}".format(val1, val2, result1))

val1 = input("실수값1 : ")
val2 = input("실수값2 : ")

result1 = val1 + val2
print("{} + {} = {}".format(val1, val2, result1))


val1 = float(input("실수값1 : "))
val2 = float(input("실수값2 : "))

result1 = val1 + val2
print("{} + {} = {}".format(val1, val2, result1))
