lines = "LGCNS\nLGWay\nDigital Innovation Leader\n"
 
fp = open('c:/temp/data4.txt', 'w') 
fp.writelines(lines)
fp.close()

