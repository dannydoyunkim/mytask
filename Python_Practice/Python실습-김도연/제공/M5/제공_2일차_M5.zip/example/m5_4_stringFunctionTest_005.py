s1 ='''What's new in Python 3.6\nTutorial
Library Reference\nLanguage Reference
Extending and Embedding\nPython/C API
Using Python\nPython HOWTOs\n'''

strList = s1.splitlines()

for str in strList:
    print(str)

print("\nJoin Test")
strJoin = '*'.join(strList)
print(strJoin)
