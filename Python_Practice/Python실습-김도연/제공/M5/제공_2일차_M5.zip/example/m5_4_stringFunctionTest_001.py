s1 = "Hello LGCNS "
s2 = "010-8790-1234"

print("s1 = ", s1)
print("s1.count('l') = ", s1.count('l'))

print("s1.find('L') = ", s1.find('L'))
print("s1.find('L', 3) = ", s1.find('L', 3))
print("s1.rfind('L') = ", s1.rfind('L'))

print("s1.index('2') = ", s2.index('2'))
print("s1.rindex('2') = ", s2.rindex('2'))


print("\ns2 = ", s2)
print("s2.startswith('010') = ", s2.startswith('010'))
print("s2.endswith('1234') = ", s2.endswith('2134'))


