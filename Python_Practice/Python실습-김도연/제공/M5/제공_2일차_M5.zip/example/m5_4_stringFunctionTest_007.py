s1 = "LGCNS"
s2 = "10928345"
s3 = "qwer123"
s4 = "    "
s5 = "What's New In Python"
s6 = "I Am Daniel"

print("s1 = ", s1)
print("s2 = ", s2)
print("s3 = ", s3)
print("s4 = ", s4)
print("s5 = ", s5)
print("s6 = ", s6)
print()
print("s1.isalpha() = ", s1.isalpha())
print("s1.isdigit() = ", s1.isdigit())
print("s2.isdigit() = ", s2.isdigit())
print("s1.islower() = ", s1.islower())
print("s1.isupper() = ", s1.isupper())
print("s2.isalnum() = ", s2.isalnum())
print("s4.isspace() = ", s4.isspace())
print("s5.istitle() = ", s5.istitle())
print("s6.istitle() = ", s6.istitle())



