s1 = "LGCNS"

print("center(20) = ", s1.center(20))
print("ljust(20) = ", s1.ljust(20))
print("rjust(20) = ", s1.rjust(20))
print("zfill(20) = ", s1.zfill(20))



