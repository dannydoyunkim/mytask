#문자열 변수끼리 더할 수 있다.
s1 = "Hello"
s2 = "LGCNS"
s3 = s1 + s2

#문자열과 문자열 변수를 더할 수 있다.
s4 = "LGCNS"
s5 = "Global Reader " + s4

#문자열과 문자열을 더할 수 있다.
s6 = "Global Reader " + "LGCNS"

#숫자를 문자열과 더하기위해 변환한다. 
s7 = "LGCNS" + str(1) + "위"

#문자열 변수를 곱하기 할 수 있다.
s8 = "LGCNS"
s9 = s1 * 5

#문자열을 곱하기 할 수 있다.
s10 = "LGCNS" * 5

#숫자를 문자열로 변환해서 곱한다.  
s11 = str(3.14) * 3


print("s1 = ", s1)
print("s2 = ", s2)
print("s3 = ", s3)
print("s4 = ", s4)
print("s5 = ", s5)
print("s6 = ", s6)
print("s7 = ", s7)
print("s8 = ", s8)
print("s9 = ", s9)
print("s10 = ", s10)
print("s11 = ", s11)

