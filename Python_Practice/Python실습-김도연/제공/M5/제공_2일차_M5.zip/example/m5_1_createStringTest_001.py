s1 = "DIGITAL INNOVATION LEADER"

s2 = '12345'

s3 = """DIGITAL INNOVATION LEADER
LG
12345
3.14
"""
s4 = '''DIGITAL INNOVATION LEADER'''

s5 = "What's your name?"

s6 = "Hello 'Kim!'"

print("s1 = ", s1)
print("s2 = ", s2)
print("s3 = ", s3)
print("s4 = ", s4)
print("s5 = ", s5)
print("s6 = ", s6)

