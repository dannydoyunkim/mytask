s1 = " Hello LGCNS "
s2 = "@@010-8790-1234@@"

print("s1 = ", s1)
print("s1.strip() = ", s1.strip())

print("s2 = ", s2)
print("s2.strip('@') = ", s2.strip('@'))

print("\ns1 = ", s1)
print("s1.rstrip() = ", s1.rstrip())
print("s1.lstrip() = ", s1.lstrip())

print("\ns1 = ", s1)
print("s1.replace() = ", s1.replace('l', 'L'))





