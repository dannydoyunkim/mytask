s1 = "DIGITAL INNOVATION LEADER"

for i in range(len(s1)):
   print(s1[i], end='')
