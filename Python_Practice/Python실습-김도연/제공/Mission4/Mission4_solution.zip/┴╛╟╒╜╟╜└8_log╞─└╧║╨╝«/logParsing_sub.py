'''
이와같은 패턴의 문제에서는 파일의 모든 라인의 구성이 같으므로 파일에서 한 줄만 이용하여
필요한 로직을 생각해야하는 연습을 하는 것도 좀 더 쉽게 접근할 수 있습니다.
해당 종합실습 폴더에 logStringTest 파일을 열어보면 data.txt 파일 중 임의의 한 줄을
이용하여 HTTP 상태값이 위치하는 곳과 이미지 파일이 위치하는 곳을 먼저 알아보았습니다.
그 위치를 알면 나머지는 각 라인 중 해당 위치(라인의 인덱스)의 값이 조건에서 제시한
내용과 일치하는지를 비교하면 됩니다.

'''
def logParser(logList):
    success = 0
    images = 0

    
    for line in logList:
        tokens = line.split()

        status = tokens[8]
        
        if status == '200':
           success +=1

        url = tokens[6].lower()      
                 
        if url.find("?") != -1: #?가 있는지 확인한다. 만약 없으면 -1를 리턴하므로 판단하여
            url = url[0:url.index("?")]  # -1로 리턴되지 않으면 ?이전 부분까지 잘라낸다.
               

        if url.endswith(".jpg") or url.endswith(".gif") or url.endswith(".png"):
            images+=1   

    return success, images         


        

      
         

