checkPattern = [(0, -1), (-1, 0), (1, 0), (0, 1)]
checkedFlag = 'o'

def checkNode(datas, x, y):    
    datas[y][x] = checkedFlag   #체크한 좌표는 다시 체크 하지 않도록 하기위해 'o'로 변경시킨다. 
    for pattern in checkPattern:
        coord = (x + pattern[0], y + pattern[1])
        if (0 <= coord[1] < len(datas)) and (0 <= coord[0] < len(datas[coord[1]])):
            data = datas[coord[1]][coord[0]]
            
            if data != checkedFlag:                
                if data == "E": 
                    print("Found 'E' at", coord)
                    return True
                elif data == " ":
                    # recursive search
                    # 한 좌표에서 상하좌우를 조사하며 가능한 경로를 체크하도록 한다.
                    if checkNode(datas, coord[0], coord[1]):
                        return True
    return False


def isPossible(data):
    # 문자열 형태인 data를 리스트로 변환
    datas = [list(line) for line in data.split("|")]

    #미로 화면 출력
    for i in datas:
        print(''.join(list(i)))
        
    # 시작지점 "S"의 위치를 찾는다.
    sX, sY = 0, 0
    
    for y in range(len(datas)):
        if "S" in datas[y]:
            sX, sY = datas[y].index("S"), y
            
    # 찾기시작          
    if not checkNode(datas, sX, sY):
        print("Not found.")



