def addList(result, input1, input2):
    print(input1, input2)
    input1 = input1[::-1]
    input2 = input2[::-1]
    print(input1, input2)
    num1, num2 = '', ''
    for i in range(len(input1)):
        num1 += str(input1[i])
        num2 += str(input2[i])

    num = int(num1) + int(num2)

    # strnum = str(num)
    numlist = list(str(num))[::-1]

    for i in range(len(numlist)):
        result[i] = int(numlist[i])


def printList(listvalue):
    print("[", end='')
    for i in range(len(listvalue)):
        if i != len(listvalue)-1:
            print("{}, ".format(listvalue[i]),end='')
        else:
            print("{}".format(listvalue[i]),end='')
    print("]")
