def addList(result, input1, input2):
    input1 = input1[::-1]
    input2 = input2[::-1]

    num1, num2 = 0, 0
    for i in range(len(input1)):
        num1 += input1[i] * (10**(len(input1)-1-i))
        num2 += input2[i] * (10**(len(input2)-1-i))

    num = num1 + num2

    numlist = list(str(num))[::-1]

    for i in range(len(numlist)):
        result[i] = int(numlist[i])


def printList(listvalue):
    print("[", end='')
    for i in range(len(listvalue)):
        if i != len(listvalue)-1:
            print("{}, ".format(listvalue[i]),end='')
        else:
            print("{}".format(listvalue[i]),end='')
    print("]")
