def addList(result, input1, input2):
    sample1 = ''.join(map(str,input1[::-1]))
    sample2 = ''.join(map(str,input2[::-1]))

    sum = str(int(sample1) + int(sample2))
    tmp3 = list(sum)[::-1]
    for i in range(3):
        result[i] = int(tmp3[i])


def printList(listvalue):
    print("[", end=' ')
    for i in range(3):
        print("%d" % listvalue[i], end = '')
        if (i != 2):
            print(", ", end='')
    print("]")
