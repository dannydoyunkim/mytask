def addList(result, input1, input2):
    sample = list(map(str, reversed(input1)))
    tmp = ''.join(sample)
    tmp2 = ''.join(list(map(str, reversed(input2))))
    sum = str(int(tmp) + int(tmp2))
    tmp3 = list(reversed(sum))
    for i in range(3):
        result[i] = int(tmp3[i])


def printList(listvalue):
    print("[", end='')

    for i in range(3):
        print("%d" % listvalue[i], end='')
        if (i != 2):
            print(", ", end='')
    print("]")
