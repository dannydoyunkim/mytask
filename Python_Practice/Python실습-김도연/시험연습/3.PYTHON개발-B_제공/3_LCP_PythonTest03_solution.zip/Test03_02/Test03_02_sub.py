
def selectBestCustomer(inList) :
    print(inList)
    
    retList = [] # 우수고객 선발 결과 2차원 리스트. 예) [[‘BBB’, 350, 1],  [‘AAA’, 200, 2], [‘EEE’, 200, 2] ~~~]

    #####  이 부분을 코딩하시오 ####
    # ---------------------------------->

    cosList = {}
    size = len(inList)

    for i in range(0, size, 2):
        if inList[i] in cosList:
            cosList[inList[i]] = cosList[inList[i]] + int(inList[i+1])
        else :
            cosList[inList[i]] = int(inList[i+1])

    retList = list()
    for i in cosList.keys():
        retList.append([i,cosList[i]])
   
    for i in range(0, len(retList)):
        for k in range(0, len(retList)-1-i):
            if retList[k][1] < retList[k+1][1]:
                tmp = retList[k]
                retList[k] =  retList[k+1]
                retList[k+1] = tmp
   
    rank = 1
    realrank = 1

    for i in range(len(retList)):
        retList[i].append(realrank)
        if i == len(retList)-1:
            break
        if(retList[i][1] == retList[i+1][1]):
            rank +=1
            continue
        else:
            rank +=1
            realrank = rank

    
    # <--------------------------------
    ##########################

    return retList
