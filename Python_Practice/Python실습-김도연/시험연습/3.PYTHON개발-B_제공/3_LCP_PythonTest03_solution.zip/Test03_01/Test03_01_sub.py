﻿def myPass(myCars):

    totalCost = 0  # 자동차 통행료 합계 (소형:1000, 중형:3000, 대형:5000, 경차/친환경차:면제)
    freeCount = 0 # 면제 자동차 대수

    #####  이 부분을 코딩하시오 ####
    # ---------------------------------->
    cost = {'소형': 1000, '중형': 3000, '대형': 5000, '경차': 0, '친환경차': 0}
    costCalculator = {}

    for car in myCars:
        if cost[car] == 0:
            freeCount += 1
        else :
            if car in costCalculator:
                costCalculator[car] = costCalculator[car] + cost[car]
            else:
                costCalculator[car] = cost[car]
        totalCost += cost[car]

    return [totalCost, freeCount]
