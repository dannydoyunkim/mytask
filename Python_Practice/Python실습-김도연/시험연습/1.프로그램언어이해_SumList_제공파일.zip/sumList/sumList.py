def addList(result, input1, input2):
    pass


def printList(listvalue):
    print("[", end='')

    # TODO
    print("]")
