total = 0 # 변수를 선언하지 않으면 사용할 수 없음. 따라서, 사용해야함.

for item in range(1,11): # 1-10까지 증가해서 i에 대입
    total += item

print(" 1~10 summation result : {}".format(sum))

# print("{} hong".format(num))
# print("%d hong" % (i) )