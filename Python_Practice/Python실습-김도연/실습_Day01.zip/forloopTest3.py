total = 0

for item in "HelloLGCNS" :
    print(item, end=' ')
    total = total + 1

print("\n\n문자열은 총", total, "글자로 이루어져 있습니다.\n")

tmp = "HelloLGCNS"
total1 = 0

for i in range(len(tmp)) :
    print(tmp[i], end=' ')
    total1 = total1 + 1

print("\n\n문자열은 총", total1, "글자로 이루어져 있습니다.")
