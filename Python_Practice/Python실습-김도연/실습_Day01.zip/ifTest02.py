score = 50

if(score % 2 == 0) :
    print("짝수")
else:
    print("홀수")

print("종료")