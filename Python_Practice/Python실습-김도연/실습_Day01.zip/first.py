"""
print('H e l l o')
print("H e l l o")
print(100)
print("Hello CNS", 100, 3.14)
print(input("값 입력 : "))
"""

# print("hello", 100, 3.14)

# a = 10
# b = 3.14
# c = "hello"
#
# print(type(a))
# print(type(b))
# print(type(c))
#
# a = 3.3
# print(type(a))

# a = int(input("정수 값 : "))
# print(a)
# print(a+100)
#
# f = float(input("실수 값 : "))
# print(f)
# print(f+100)

a = "1234"
print(type(a))
print(a + str(100))
print(a * 3)
print(a[3]) # 문자열의 0,1,2, 3 번째 문자 값

b = 1234
print(b)




