score = 50

if(score > 0) :
    print("양수")
else:
    if(score < 0) :
        print("음수")
    else :
        print("0")

print("종료")