continue_letter = input("건너뛸 문자를 입력하세요:")

for letter in "ptythontaut" :
    if letter == continue_letter :
        continue
    print(letter)