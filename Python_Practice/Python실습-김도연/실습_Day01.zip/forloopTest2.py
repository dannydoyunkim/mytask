total = 0

for i in range(20, -1, -1) : # 0 까지만 실행됨
    if i % 2 != 1 :
        print(i, end='')
