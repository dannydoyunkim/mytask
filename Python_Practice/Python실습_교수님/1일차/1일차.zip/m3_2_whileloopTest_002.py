value = 1

while value <= 100:
    value = int(input("숫자 입력 :"))
    print("입력된 값 :", value)