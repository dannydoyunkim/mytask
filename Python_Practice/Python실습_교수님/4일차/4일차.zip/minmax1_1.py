score = [55, 86, 97, 84, 33 ]
max1 = min(score)
min1 = max(score)


print("최대값: ", max1)
print("최소값: ", min1)
