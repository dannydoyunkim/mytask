score = [55, 86, 97, 84, 33 ]
max = score[0]
min = score[0]
for i in range(1, len(score)):
    if score[i] > max:
        max = score[i]
    if score[i] < min:
        min = score[i]

print("최대값: ", max)
print("최소값: ", min)
